<div class="header-video">
	<div id="hero_video">
		<div class="opacity-mask d-flex align-items-center" data-opacity-mask="rgba(0, 0, 0, 0.6)">
			<div class="container">
				<div class="row justify-content-center text-center">
					<div class="col-xl-8 col-lg-10 col-md-8">
                            <h1>Yerosan Hotel</h1>
                            <p>The best restaurants at the best price</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<img src="{{ URL::asset('/img/video_fix.png') }}" alt="" class="header-video--media" data-video-src="video/intro" data-teaser-source="video/intro" data-provider="" data-video-width="1920" data-video-height="960">
</div>
<!-- /header-video -->