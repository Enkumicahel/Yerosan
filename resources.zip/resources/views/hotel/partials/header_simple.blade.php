<div class="hero_single version_2">
    <div class="opacity-mask" data-opacity-mask="rgba(0, 0, 0, 0.6)">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-9 col-lg-10 col-md-8">
                    <h1>Yerosan Hotel</h1>
                    <p>The best restaurants at the best price</p>
                    
                </div>
            </div>
            <!-- /row -->
        </div>
    </div>
</div>